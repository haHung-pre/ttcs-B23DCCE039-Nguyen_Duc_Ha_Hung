from fastapi import FastAPI

app = FastAPI(title="TaskFlow – Hello World")

@app.get("/")
async def root():
    return {"message": "Hello TaskFlow 🚀"}
