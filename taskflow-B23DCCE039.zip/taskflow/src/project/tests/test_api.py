import pytest


# ── Auth Tests ────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_register_success(client):
    """Test 1: User can register with valid data."""
    resp = await client.post("/auth/register", json={
        "email": "newuser@example.com",
        "password": "password123",
        "full_name": "New User",
    })
    assert resp.status_code == 201
    data = resp.json()
    assert data["email"] == "newuser@example.com"
    assert data["full_name"] == "New User"
    assert "hashed_password" not in data  # password must never be exposed


@pytest.mark.anyio
async def test_register_duplicate_email(client):
    """Registering with an existing email should return 400."""
    payload = {"email": "dup@example.com", "password": "password123"}
    await client.post("/auth/register", json=payload)
    resp = await client.post("/auth/register", json=payload)
    assert resp.status_code == 400
    assert "already registered" in resp.json()["detail"]


@pytest.mark.anyio
async def test_login_success(client):
    """Test 2: Registered user can login and receive a JWT token."""
    await client.post("/auth/register", json={
        "email": "login@example.com",
        "password": "password123",
    })
    resp = await client.post("/auth/login", data={
        "username": "login@example.com",
        "password": "password123",
    })
    assert resp.status_code == 200
    data = resp.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"


@pytest.mark.anyio
async def test_login_wrong_password(client):
    """Login with wrong password should return 401."""
    await client.post("/auth/register", json={
        "email": "wrongpw@example.com",
        "password": "password123",
    })
    resp = await client.post("/auth/login", data={
        "username": "wrongpw@example.com",
        "password": "wrongpassword",
    })
    assert resp.status_code == 401


# ── Task Tests ────────────────────────────────────────────────────────────────

@pytest.mark.anyio
async def test_create_task(auth_client):
    """Test 3: Authenticated user can create a task."""
    resp = await auth_client.post("/tasks/", json={
        "title": "Buy groceries",
        "description": "Milk, eggs, bread",
        "status": "TODO",
        "priority": "HIGH",
    })
    assert resp.status_code == 201
    data = resp.json()
    assert data["title"] == "Buy groceries"
    assert data["status"] == "TODO"
    assert data["priority"] == "HIGH"
    assert "id" in data


@pytest.mark.anyio
async def test_list_tasks(auth_client):
    """Test 4: Authenticated user can list their tasks with pagination."""
    # Create 3 tasks first
    for i in range(3):
        await auth_client.post("/tasks/", json={"title": f"Task {i}"})

    resp = await auth_client.get("/tasks/?page=1&limit=10")
    assert resp.status_code == 200
    data = resp.json()
    assert "items" in data
    assert "total" in data
    assert "page" in data
    assert data["page"] == 1
    assert len(data["items"]) >= 3


@pytest.mark.anyio
async def test_unauthorized_access():
    """Test 5: Accessing tasks without token should return 401."""
    from httpx import AsyncClient, ASGITransport
    from app.main import app
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.get("/tasks/")
    assert resp.status_code == 401


@pytest.mark.anyio
async def test_update_task(auth_client):
    """Updating a task should reflect the changes."""
    create_resp = await auth_client.post("/tasks/", json={"title": "Original Title"})
    task_id = create_resp.json()["id"]

    update_resp = await auth_client.put(f"/tasks/{task_id}", json={
        "title": "Updated Title",
        "status": "IN_PROGRESS",
    })
    assert update_resp.status_code == 200
    data = update_resp.json()
    assert data["title"] == "Updated Title"
    assert data["status"] == "IN_PROGRESS"


@pytest.mark.anyio
async def test_delete_task(auth_client):
    """Deleting a task should return 204 and the task should no longer exist."""
    create_resp = await auth_client.post("/tasks/", json={"title": "To be deleted"})
    task_id = create_resp.json()["id"]

    del_resp = await auth_client.delete(f"/tasks/{task_id}")
    assert del_resp.status_code == 204

    get_resp = await auth_client.get(f"/tasks/{task_id}")
    assert get_resp.status_code == 404


@pytest.mark.anyio
async def test_filter_tasks_by_status(auth_client):
    """Filtering tasks by status should only return matching tasks."""
    await auth_client.post("/tasks/", json={"title": "Done task", "status": "DONE"})
    await auth_client.post("/tasks/", json={"title": "Todo task", "status": "TODO"})

    resp = await auth_client.get("/tasks/?status=DONE")
    assert resp.status_code == 200
    items = resp.json()["items"]
    assert all(t["status"] == "DONE" for t in items)
