from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.models.task import Task, TaskStatus, TaskPriority
from app.schemas.task import TaskCreate, TaskUpdate


class TaskService:

    @staticmethod
    async def get_all(
        db: AsyncSession,
        user_id: int,
        status: TaskStatus | None = None,
        priority: TaskPriority | None = None,
        page: int = 1,
        limit: int = 10,
    ):
        query = select(Task).where(Task.user_id == user_id)

        if status:
            query = query.where(Task.status == status)
        if priority:
            query = query.where(Task.priority == priority)

        # Count total
        count_query = select(func.count()).select_from(query.subquery())
        total_result = await db.execute(count_query)
        total = total_result.scalar_one()

        # Paginate
        offset = (page - 1) * limit
        query = query.order_by(Task.created_at.desc()).offset(offset).limit(limit)
        result = await db.execute(query)
        tasks = result.scalars().all()

        return total, tasks

    @staticmethod
    async def get_by_id(db: AsyncSession, task_id: int, user_id: int) -> Task | None:
        result = await db.execute(
            select(Task).where(Task.id == task_id, Task.user_id == user_id)
        )
        return result.scalar_one_or_none()

    @staticmethod
    async def create(db: AsyncSession, task_in: TaskCreate, user_id: int) -> Task:
        task = Task(**task_in.model_dump(), user_id=user_id)
        db.add(task)
        await db.flush()
        await db.refresh(task)
        return task

    @staticmethod
    async def update(db: AsyncSession, task: Task, task_in: TaskUpdate) -> Task:
        update_data = task_in.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(task, field, value)
        await db.flush()
        await db.refresh(task)
        return task

    @staticmethod
    async def delete(db: AsyncSession, task: Task) -> None:
        await db.delete(task)
        await db.flush()
