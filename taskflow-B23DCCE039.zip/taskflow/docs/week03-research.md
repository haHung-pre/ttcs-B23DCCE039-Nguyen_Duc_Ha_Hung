# Week 03 – Research Notes: JWT Authentication

**Thời gian:** 09/03 – 15/03/2026
**Chủ đề:** JWT Auth, bcrypt, project structure

---

## 1. JWT – Giải thích bằng lời

JWT (JSON Web Token) gồm 3 phần ngăn cách bởi dấu `.`:

```
eyJhbGciOiJIUzI1NiJ9   ← Header (base64): thuật toán dùng
.eyJzdWIiOiIxIn0       ← Payload (base64): data (user_id, expiry)
.SflKxwRJSMeKKF2QT4    ← Signature: HMAC(header+payload, SECRET_KEY)
```

**Tại sao stateless?** Server không cần lưu token. Chỉ cần verify chữ ký bằng `SECRET_KEY`. Nếu chữ ký hợp lệ và token chưa hết hạn → trust.

**Flow hoàn chỉnh:**
```
1. User POST /auth/login  {email, password}
2. Server verify password (bcrypt)
3. Server tạo JWT: {sub: user_id, exp: now+30min} + ký bằng SECRET_KEY
4. Server trả token về client
5. Client lưu token (localStorage / memory)
6. Mỗi request tiếp theo: Header "Authorization: Bearer <token>"
7. Server decode token → lấy user_id → query user → attach vào request
```

---

## 2. Tại sao bcrypt?

```python
# ❌ Không bao giờ lưu plain text
user.password = "mypassword123"

# ❌ Không dùng MD5/SHA1 – có thể brute force bằng rainbow table
user.password = md5("mypassword123")

# ✅ bcrypt – có salt tự động, không thể reverse
user.hashed_password = bcrypt.hash("mypassword123")
# → "$2b$12$someRandomSalt...hashedResult"
```

bcrypt tự sinh salt ngẫu nhiên mỗi lần hash → cùng password nhưng 2 lần hash cho ra kết quả khác nhau. Không thể dùng rainbow table.

---

## 3. Cấu trúc project production-ready

```
app/
├── main.py              ← chỉ khởi tạo app, register router, middleware
├── core/
│   ├── config.py        ← tất cả config từ env vars
│   └── security.py      ← JWT utils, get_current_user dependency
├── db/
│   └── session.py       ← engine, session, Base
├── models/              ← SQLAlchemy ORM models
├── schemas/             ← Pydantic request/response schemas
├── services/            ← business logic (không phụ thuộc FastAPI)
└── routers/             ← HTTP layer (chỉ validate + gọi service)
```

**Nguyên tắc:** `services/` không import gì từ FastAPI. Điều này giúp test service mà không cần start HTTP server.
