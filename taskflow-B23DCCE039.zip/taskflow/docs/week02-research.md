# Week 02 – Research Notes: PostgreSQL + SQLAlchemy Async + Alembic

**Thời gian:** 02/03 – 08/03/2026
**Chủ đề:** Kết nối database thực sự, ORM async, migration

---

## 1. Tại sao không dùng `create_all()` trong production?

`Base.metadata.create_all()` tạo bảng nếu chưa có – nhưng nếu bảng đã có, nó **không làm gì cả**. Điều này nghĩa là khi bạn thêm một cột mới vào model, `create_all()` sẽ im lặng bỏ qua. Cột mới sẽ không được tạo, app sẽ crash khi query.

**Alembic** giải quyết vấn đề này bằng cách:
1. Track lịch sử thay đổi schema qua các file migration có version
2. Mỗi migration có `upgrade()` và `downgrade()` → rollback được
3. Biết database đang ở version nào qua bảng `alembic_version`

---

## 2. SQLAlchemy 2.0 Async – điểm khác biệt chính

```python
# ❌ Sync (SQLAlchemy 1.x style) – blocking I/O
result = db.execute(select(Task))
tasks = result.scalars().all()

# ✅ Async (SQLAlchemy 2.0) – non-blocking
result = await db.execute(select(Task))
tasks = result.scalars().all()
```

**Lỗi tôi gặp:** `MissingGreenlet` khi dùng lazy loading với async session.
**Nguyên nhân:** SQLAlchemy async không hỗ trợ lazy load vì nó cần trigger I/O từ Python attribute access – không thể `await` từ `__get__`.
**Fix:** Dùng `selectinload()` hoặc `joinedload()` khi cần load relationship.

```python
# Fix: eager load relationship
result = await db.execute(
    select(Task).options(selectinload(Task.owner))
)
```

---

## 3. Dependency Injection với `Depends()`

```python
async def get_db():
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise

@router.get("/tasks")
async def list_tasks(db: AsyncSession = Depends(get_db)):
    # db session được inject tự động
    # session tự commit/rollback/close sau request
    ...
```

**Tại sao hay:** Session lifecycle được quản lý tập trung. Mọi route không cần viết try/finally thủ công.

---

## 4. Repository Pattern

Thay vì viết SQL/ORM trực tiếp trong route handler:

```python
# ❌ Không nên – logic lẫn lộn trong router
@router.get("/tasks/{id}")
async def get_task(id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Task).where(Task.id == id))
    return result.scalar_one_or_none()
```

Tách ra service/repository riêng:

```python
# ✅ Router chỉ gọi service
@router.get("/tasks/{id}")
async def get_task(id: int, db: AsyncSession = Depends(get_db)):
    task = await TaskService.get_by_id(db, id)
    if not task:
        raise HTTPException(404, "Not found")
    return task
```

**Lợi ích:** Dễ test (mock service), dễ swap database sau này mà không sửa router.
