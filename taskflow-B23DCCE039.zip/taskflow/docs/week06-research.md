# Week 06 – Research Notes: CI/CD với GitHub Actions

**Thời gian:** 30/03 – 05/04/2026
**Chủ đề:** GitHub Actions workflow, Docker Hub, Railway deployment

---

## 1. CI/CD là gì và tại sao cần?

**Không có CI/CD:**
```
dev push code → "works on my machine" → deploy thủ công → production crash
```

**Có CI/CD:**
```
dev push code → tests tự chạy → build Docker → deploy tự động → production ổn định
```

CI/CD không chỉ tiết kiệm thời gian – nó là safety net. Không có test xanh thì không thể deploy.

---

## 2. Anatomy của một GitHub Actions Workflow

```yaml
name: CI                    # Tên hiển thị trên GitHub

on:                         # Trigger: khi nào chạy
  push:
    branches: ["**"]        # Mọi branch khi push
  pull_request:
    branches: [main]        # PR vào main

jobs:                       # Các job (chạy song song mặc định)
  test:                     # Job tên "test"
    runs-on: ubuntu-latest  # Runner
    steps:                  # Các bước (chạy tuần tự)
      - uses: actions/checkout@v4   # Checkout code
      - name: Run tests
        run: pytest tests/          # Chạy lệnh shell
```

**Concepts:**
- **Workflow** = file YAML trong `.github/workflows/`
- **Job** = nhóm steps, chạy trên 1 runner riêng
- **Step** = 1 action hoặc 1 shell command
- **Runner** = máy ảo Ubuntu/Windows/macOS của GitHub

---

## 3. CI/CD Pipeline của TaskFlow API

```mermaid
graph LR
    A[git push] --> B[GitHub Actions trigger]
    B --> C[Job: test]
    C --> D{Tests pass?}
    D -->|No| E[❌ Pipeline fail - không deploy]
    D -->|Yes| F[Job: build-and-push]
    F --> G[Build Docker image]
    G --> H[Push to Docker Hub]
    H --> I[Railway webhook]
    I --> J[🚀 Redeploy production]
```

---

## 4. Secrets Management

```yaml
# ❌ KHÔNG BAO GIỜ hardcode credentials trong workflow
- run: docker login -u myusername -p mypassword123

# ✅ Dùng GitHub Secrets
- uses: docker/login-action@v3
  with:
    username: ${{ secrets.DOCKERHUB_USERNAME }}
    password: ${{ secrets.DOCKERHUB_TOKEN }}
```

Secrets lưu trong **Settings → Secrets and variables → Actions**. Không bao giờ in ra log dù có `echo ${{ secrets.FOO }}`.

---

## 5. Lỗi tôi gặp và cách fix

**Lỗi:** CI fail với `connection refused` khi test kết nối PostgreSQL service.

**Nguyên nhân:** PostgreSQL container start nhưng chưa sẵn sàng nhận connection khi test chạy.

**Fix:** Thêm health check vào service config trong workflow:
```yaml
services:
  postgres:
    image: postgres:16-alpine
    options: >-
      --health-cmd pg_isready
      --health-interval 10s
      --health-timeout 5s
      --health-retries 5
```

Sau khi fix, GitHub Actions đợi PostgreSQL healthy trước khi chạy test. Pipeline xanh ✅.

---

## 6. Kết quả tuần này

- ✅ CI pipeline: test tự động chạy mỗi lần push
- ✅ Docker image build + push lên Docker Hub sau mỗi push vào main
- ✅ CD pipeline: deploy tự động lên Railway
- ✅ Live API tại: https://taskflow-api.up.railway.app/docs

**Cảm nhận:** Lần đầu push code và thấy pipeline xanh ✅, rồi vào link Railway thấy phiên bản mới đã deploy – đây là khoảnh khắc "aha moment" thực sự của đợt thực tập này.
