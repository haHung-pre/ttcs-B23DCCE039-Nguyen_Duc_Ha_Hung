# Week 01 – Research Notes: FastAPI Fundamentals

**Thời gian:** 23/02 – 01/03/2026
**Chủ đề:** Làm quen với FastAPI, Pydantic, HTTP basics

---

## 1. Tại sao chọn FastAPI thay vì Flask?

Trước khi bắt đầu tuần này, tôi chỉ biết Flask. Sau khi đọc tài liệu và so sánh, tôi hiểu được sự khác biệt cốt lõi:

| Tiêu chí | Flask | FastAPI |
|---|---|---|
| Performance | Sync (blocking) | Async (non-blocking) bằng Starlette |
| Validation | Thủ công (if/else) | Tự động qua Pydantic + type hints |
| API Docs | Cần cài thêm Flask-Swagger | Tự sinh Swagger UI + ReDoc tại `/docs` |
| Type safety | Không có | Full type hints, IDE gợi ý đúng |
| Learning curve | Thấp | Thấp – nếu đã biết Python type hints |

**Kết luận cá nhân:** FastAPI không khó hơn Flask, nhưng cho ra kết quả "production-ready" nhanh hơn nhiều vì validation và docs được handle tự động.

---

## 2. Cách Pydantic hoạt động

Pydantic dùng Python type hints để validate data **tại runtime**. Ví dụ:

```python
class TaskCreate(BaseModel):
    title: str        # bắt buộc, phải là string
    priority: int     # bắt buộc, phải là số nguyên
```

Nếu client gửi `{"title": 123}` → Pydantic vẫn chấp nhận vì `str(123) = "123"`.
Nếu client gửi `{"priority": "abc"}` → FastAPI tự trả `422 Unprocessable Entity` mà không cần code gì thêm.

**Điều này quan trọng:** Không cần viết `if not isinstance(title, str): raise ValueError(...)` nữa. Pydantic làm hết.

---

## 3. Luồng request-response trong FastAPI

```
Client gửi HTTP Request
        ↓
FastAPI nhận → parse path/query/body params
        ↓
Pydantic validate request data
        ↓ (nếu sai → 422 tự động)
Route handler function được gọi
        ↓
Business logic xử lý
        ↓
Pydantic serialize response object → JSON
        ↓
Client nhận HTTP Response
```

---

## 4. Ba cách nhận input trong FastAPI

```python
# 1. Path parameter – nằm trong URL
@app.get("/tasks/{task_id}")
async def get_task(task_id: int):  # /tasks/42 → task_id = 42
    ...

# 2. Query parameter – sau dấu ?
@app.get("/tasks")
async def list_tasks(status: str = "TODO"):  # /tasks?status=DONE
    ...

# 3. Request Body – JSON trong body
@app.post("/tasks")
async def create_task(task: TaskCreate):  # JSON body được parse tự động
    ...
```

---

## 5. HTTP Status Codes – cách dùng đúng

Sai phổ biến: dùng `200 OK` cho mọi response kể cả khi có lỗi.

Chuẩn:
- `200 OK` – GET thành công, PUT thành công
- `201 Created` – POST tạo resource mới thành công
- `204 No Content` – DELETE thành công (không có body)
- `400 Bad Request` – Client gửi data sai logic (email đã tồn tại)
- `401 Unauthorized` – Chưa xác thực (không có token)
- `403 Forbidden` – Đã xác thực nhưng không có quyền
- `404 Not Found` – Resource không tồn tại
- `422 Unprocessable Entity` – Dữ liệu sai format (Pydantic tự throw)
- `500 Internal Server Error` – Lỗi server không mong đợi

---

## 6. Kết quả thực hành tuần này

- ✅ Cài đặt môi trường Python 3.11 + venv
- ✅ API CRUD Task in-memory với đủ 5 endpoint
- ✅ Swagger UI tự sinh đúng schema từ Pydantic models
- ✅ Phân biệt được `TaskCreate` (input) và `TaskResponse` (output)

**Điều tôi tự hào:** Lần đầu thấy Swagger UI tự sinh – không cần viết thêm gì – thực sự ấn tượng.
