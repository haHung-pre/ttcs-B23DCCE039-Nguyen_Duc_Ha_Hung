# Week 05 – Research Notes: Docker & Docker Compose

**Thời gian:** 23/03 – 29/03/2026
**Chủ đề:** Dockerfile multi-stage, Docker Compose, volumes

---

## 1. Docker Concepts – Nền tảng

| Khái niệm | Giải thích đơn giản |
|---|---|
| Image | Blueprint bất biến (như class trong OOP) |
| Container | Instance đang chạy (như object) |
| Layer | Mỗi `RUN`/`COPY`/`ADD` tạo một layer, được cache |
| Volume | Thư mục mount vào container, data persist ngoài container lifecycle |

**Cache layer quan trọng:** Thứ tự instruction trong `Dockerfile` ảnh hưởng tốc độ build.

```dockerfile
# ❌ Chậm – thay đổi bất kỳ file nào cũng rebuild deps
COPY . .
RUN pip install -r requirements.txt

# ✅ Nhanh – deps chỉ rebuild khi requirements.txt thay đổi
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
```

---

## 2. Multi-stage Build – Tại sao quan trọng?

```dockerfile
# Stage 1: Builder – có đủ build tools (gcc, libpq-dev...)
FROM python:3.11-slim AS builder
RUN pip install --prefix=/install -r requirements.txt

# Stage 2: Runtime – chỉ copy kết quả, bỏ build tools
FROM python:3.11-slim AS runtime
COPY --from=builder /install /usr/local
COPY app/ ./app/
```

**Kết quả:** Image size từ ~800MB xuống còn **178MB**. Không có build tools, không có cache pip → image nhỏ hơn, an toàn hơn.

---

## 3. `depends_on` vs `healthcheck`

```yaml
# ❌ Không đủ – container db start trước nhưng PostgreSQL chưa accept connection
depends_on:
  - db

# ✅ Đúng – đợi đến khi PostgreSQL thực sự sẵn sàng
depends_on:
  db:
    condition: service_healthy
```

`healthcheck` dùng `pg_isready` để check PostgreSQL đã sẵn sàng nhận connection chưa. Không có healthcheck thì app start trước khi DB ready → crash "connection refused".

---

## 4. Named Volume vs Anonymous Volume

```yaml
volumes:
  - postgres_data:/var/lib/postgresql/data  # Named volume – persist sau docker compose down
  - /var/lib/postgresql/data                # Anonymous volume – BỊ XOÁ khi docker compose down
```

**Bài học đau:** Lần đầu dùng anonymous volume, chạy `docker compose down` xong data mất hết. Sau khi đọc docs mới hiểu phải dùng named volume.

---

## 5. Kết quả thực hành

Sau khi hoàn thiện Docker setup, tôi clone repo về máy mới và chạy:
```bash
cp .env.example .env
docker compose up --build
```
Sau ~2 phút, cả API + PostgreSQL + pgAdmin đều chạy. Không cần cài Python hay PostgreSQL local. Đây chính xác là giá trị của Docker.
