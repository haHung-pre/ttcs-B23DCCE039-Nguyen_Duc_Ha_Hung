# References – Nguồn tham khảo

Tổng hợp tất cả tài liệu đã đọc và tham khảo trong suốt đợt thực tập.

---

## 📘 Official Documentation

| # | Tên | Link | Tuần dùng |
|---|-----|------|-----------|
| 1 | FastAPI Official Docs | https://fastapi.tiangolo.com | Tuần 1–4 |
| 2 | Pydantic v2 Docs | https://docs.pydantic.dev | Tuần 1–4 |
| 3 | SQLAlchemy 2.0 Async | https://docs.sqlalchemy.org/en/20/orm/extensions/asyncio.html | Tuần 2 |
| 4 | Alembic Documentation | https://alembic.sqlalchemy.org | Tuần 2 |
| 5 | Docker Official Docs | https://docs.docker.com | Tuần 5 |
| 6 | Docker Compose Reference | https://docs.docker.com/compose | Tuần 5 |
| 7 | GitHub Actions Docs | https://docs.github.com/en/actions | Tuần 6 |
| 8 | Railway Documentation | https://railway.app/docs | Tuần 6 |
| 9 | JWT Introduction | https://jwt.io/introduction | Tuần 3 |

---

## 📝 Blogs & Articles

| # | Tên | Link | Tuần dùng |
|---|-----|------|-----------|
| 10 | FastAPI Best Practices | https://github.com/zhanymkanov/fastapi-best-practices | Tuần 3 |
| 11 | Testing FastAPI with pytest | https://testdriven.io/blog/fastapi-crud/ | Tuần 2, 4 |
| 12 | 12-Factor App – Config | https://12factor.net/config | Tuần 4 |
| 13 | Dockerfile Best Practices | https://docs.docker.com/develop/develop-images/dockerfile_best-practices/ | Tuần 5 |
| 14 | FastAPI + SQLAlchemy Async Tutorial | https://medium.com/@estretyakov/the-ultimate-async-setup-fastapi-sqlmodel-alembic-pytest-ae5cdcfed3d4 | Tuần 2 |
| 15 | Backend Developer Roadmap | https://roadmap.sh/backend | Tuần 1 |
| 16 | HTTP Status Codes | https://developer.mozilla.org/en-US/docs/Web/HTTP/Status | Tuần 1 |

---

## 🎥 Videos

| # | Tên | Link | Tuần dùng |
|---|-----|------|-----------|
| 17 | FastAPI Full Course – Traversy Media | https://www.youtube.com/watch?v=0sOvCWFmrtA | Tuần 1 |
| 18 | Docker Tutorial for Beginners | https://www.youtube.com/watch?v=fqMOX6JJhGo | Tuần 5 |
| 19 | GitHub Actions CI/CD Tutorial | https://www.youtube.com/watch?v=R8_veQiYBjI | Tuần 6 |
