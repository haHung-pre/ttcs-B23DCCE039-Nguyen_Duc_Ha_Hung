# Week 04 – Research Notes: Testing, Pagination, Config

**Thời gian:** 16/03 – 22/03/2026
**Chủ đề:** pytest async, pagination, 12-factor config

---

## 1. Testing FastAPI với pytest + httpx

```python
@pytest.mark.anyio
async def test_create_task(auth_client):
    resp = await auth_client.post("/tasks/", json={"title": "Test"})
    assert resp.status_code == 201
```

**Lỗi tôi gặp:** `RuntimeError: no running event loop`
**Nguyên nhân:** pytest không tự chạy event loop cho async test.
**Fix:** Thêm `asyncio_mode = auto` trong `pytest.ini` và dùng `@pytest.mark.anyio`.

**Nguyên tắc quan trọng:** Test phải dùng database riêng (không dùng production DB). Tôi dùng SQLite in-memory cho test để nhanh và không cần PostgreSQL khi chạy locally.

---

## 2. Pagination Pattern

```python
# Request: GET /tasks?page=2&limit=5
# offset = (2-1) * 5 = 5 → bỏ qua 5 record đầu, lấy 5 record tiếp

query = select(Task).offset(offset).limit(limit)

# Response luôn trả về metadata để client biết tổng số trang
{
    "total": 47,
    "page": 2,
    "limit": 5,
    "items": [...]
}
```

**Tại sao cần `total`?** Client cần biết có bao nhiêu trang để render pagination UI. Không có `total` thì không biết khi nào hết data.

---

## 3. 12-Factor App – Config

Nguyên tắc: **Config phải từ environment, không phải code.**

```python
# ❌ Hardcode trong code – nguy hiểm, không thể deploy nhiều môi trường
DATABASE_URL = "postgresql://localhost/mydb"
SECRET_KEY = "mysecret"

# ✅ Từ environment variables
from pydantic_settings import BaseSettings
class Settings(BaseSettings):
    DATABASE_URL: str
    SECRET_KEY: str
    class Config:
        env_file = ".env"
```

`.env` → `.gitignore` → **không bao giờ commit**.
`.env.example` → commit → cho người khác biết cần set những gì.

---

## Tự đánh giá giữa kỳ

**Kỹ năng đã vững:**
- FastAPI routing, middleware, exception handler
- Pydantic validation (request + response)
- JWT authentication flow end-to-end
- SQLAlchemy async CRUD + Alembic migration
- Repository/Service pattern

**Còn mơ hồ:**
- Alembic khi có nhiều migration conflict từ nhiều branch
- Test integration với PostgreSQL thật (hiện đang mock bằng SQLite)

**Nhìn lại:** 4 tuần đầu tập trung hoàn toàn vào FastAPI. Đây là quyết định đúng – nền tảng vững giúp Docker và CI/CD tuần sau dễ hơn nhiều.
